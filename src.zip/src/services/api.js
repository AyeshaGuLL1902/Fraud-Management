import { Flag } from "semantic-ui-react";
const BASE_URL = 'http://localhost:4000'; // Your backend URL


export const getTransactions = async () => {
  try {
    const response = await fetch(`${BASE_URL}/transactions`);
    const data = await response.json();
    console.log(response);
    return data;
  } catch (error) {
    console.error('Error fetching transactions:', error);
    return [];
  }
};

export const getTransactionDetails = async (transactionId) => {
  try {
    const response = await fetch(`${BASE_URL}/transactions/${transactionId}`);
    if (!response.ok) {
      throw new Error('Failed to fetch transaction details');
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching transaction details:', error);
    throw new Error('Failed to fetch transaction details');
  }
};


export const flagTransaction = async (transactionId) => {
  try {
    const response = await fetch(`${BASE_URL}/transactions/${transactionId}/flag`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to flag transaction');
    }

    return { message: 'Transaction flagged as suspicious' };
  } catch (error) {
    console.error('Error flagging transaction:', error);
    return { error: 'Failed to flag transaction' };
  }
};


export const allowTransaction = async (transactionId) => {
  try {
    const response = await fetch(`${BASE_URL}/transactions/${transactionId}/allow`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to allow transaction');
    }

    return { message: 'Transaction allowed' };
  } catch (error) {
    console.error('Error allowing transaction:', error);
    return { error: 'Failed to allow transaction' };
  }
};

export const commentTransaction = async (transactionId, comment) => {
  try {
    const response = await fetch(`${BASE_URL}/transactions/${transactionId}/comment`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ comment }), // Include the comment in the request body
    });

    if (!response.ok) {
      throw new Error('Failed to add comment to transaction');
    }

    return { message: 'Comment added to transaction' };
  } catch (error) {
    console.error('Error adding comment to transaction:', error);
    return { error: 'Failed to add comment to transaction' };
  }
};




export const addTransaction = async (transactionData) => {
  try {
    const response = await fetch(`${BASE_URL}/transactions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(transactionData),
    });
    console.log(transactionData);

    if (!response.ok) {
      throw new Error('Failed to add transaction');
    }

    return { success: true }; // Indicate success
  } catch (error) {
    console.error('Error adding transaction:', error);
    return { error: 'Failed to add transaction' };
  }
};
