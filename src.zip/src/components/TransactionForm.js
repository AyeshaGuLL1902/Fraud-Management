import React, { useState } from 'react';
import * as api from '../services/api'; // Import API functions

const TransactionForm = () => {
  const [transactionData, setTransactionData] = useState({
    amount: '',
    description: '',
    // Other transaction fields...
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await api.addTransaction(transactionData); // Use the API function to post data

      if (!response.error) {
        // Transaction successfully added, handle success (e.g., clear form)
        setTransactionData({ amount: '', description: '' /* Reset other fields */ });
        // Update UI or perform any necessary actions
      } else {
        // Handle error response from API (display error message, etc.)
        console.error('Error adding transaction:', response.error);
      }
    } catch (error) {
      console.error('Error adding transaction:', error);
      // Handle other types of errors (e.g., network issues)
    }
  };

  // Handle input changes to update transactionData state

  return (
    <div>
      <h2>Add New Transaction</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="amount">Amount:</label>
          <input
            type="text"
            id="amount"
            value={transactionData.amount}
            onChange={(e) => setTransactionData({ ...transactionData, amount: e.target.value })}
          />
        </div>
        <div>
          <label htmlFor="description">Description:</label>
          <input
            type="text"
            id="description"
            value={transactionData.description}
            onChange={(e) => setTransactionData({ ...transactionData, description: e.target.value })}
          />
        </div>
        {/* Other input fields for additional transaction information */}
        <button type="submit">Add Transaction</button>
      </form>
    </div>
  );
};

export default TransactionForm;
