import React, { useState } from 'react';
import * as api from '../services/api'; // Import API functions

const CommentSection = ({ transactionId }) => {
  const [comment, setComment] = useState('');

  const handleComment = async () => {
    if (comment.trim() !== '') {
      await api.commentTransaction(transactionId, comment); // Add comment to the transaction
      // Refresh or update comments section after adding the comment
    }
  };

  return (
    <div>
      <h3>Comments</h3>
      <div>
        <input type="text" value={comment} onChange={(e) => setComment(e.target.value)} />
        <button onClick={handleComment}>Add Comment</button>
      </div>
      {/* Display existing comments */}
      {/* Use data from the transaction to display existing comments */}
    </div>
  );
};

export default CommentSection;
