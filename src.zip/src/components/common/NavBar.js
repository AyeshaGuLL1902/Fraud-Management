// import React from 'react';
import { Menu } from 'semantic-ui-react';
import { Link } from 'react-router-dom';

const NavBar = () => {

  return (
    <Menu borderless fixed='top'>
        <Menu.Item name="Home" as={Link} to="/" />
        <Menu.Item name="Transactions" as={Link} to="/Transactions"/>

    </Menu>
  );
};

export default NavBar;
