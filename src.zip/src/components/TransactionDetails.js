import React, { useState } from 'react';
import * as api from '../services/api'; // Import API functions

const TransactionDetails = ({ transaction }) => {
  const [comment, setComment] = useState('');

  const handleComment = async () => {
    if (comment.trim() !== '') {
      await api.commentTransaction(transaction.id, comment); // Add comment to the transaction
      // Refresh or update transaction details after adding the comment
    }
  };

  return (
    <div>
      <h2>Transaction Details</h2>
      {transaction && (
        <div>
          <p>Transaction ID: {transaction.id}</p>
          <p>Amount: {transaction.amount}</p>
          {/* Display other transaction details */}
          <div>
            <input type="text" value={comment} onChange={(e) => setComment(e.target.value)} />
            <button onClick={handleComment}>Add Comment</button>
          </div>
          {/* Display existing comments */}
          {transaction.comments.map((c, index) => (
            <p key={index}>{c}</p>
          ))}
        </div>
      )}
    </div>
  );
};

export default TransactionDetails;
