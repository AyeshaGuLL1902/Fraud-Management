import React, { useState, useEffect } from 'react';
import * as api from '../services/api'; // Import API functions

const TransactionList = () => {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    const fetchTransactions = async () => {
      const data = await api.getTransactions(); // Fetch transactions from the backend
      setTransactions(data);
    };

    fetchTransactions();
  }, []);

  return (
    <div>
      <h2>Suspicious Transactions</h2>
      <ul>
        {transactions.map((transaction) => (
          <li key={transaction.id}>
            <p>Transaction ID: {transaction.id}</p>
            <p>Amount: {transaction.amount}</p>
            {/* Display other transaction details */}
            <button onClick={() => api.flagTransaction(transaction.id)}>Flag</button>
            <button onClick={() => api.allowTransaction(transaction.id)}>Allow</button>
            <button onClick={() => api.commentTransaction(transaction.id)}>Comment</button>
            {/* <button onClick={() => handleComment(transaction.id)}>Comment</button> */}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TransactionList;
