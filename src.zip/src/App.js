// App.js

import React, { useState, useEffect } from 'react';
// import TransactionList from './components/TransactionList';
// import TransactionDetails from './Pages/TransactionDetails';
// import TransactionForm from './components/TransactionForm'; 
import CommentSection from './Pages/CommentSection';
import NavBar from './components/common/NavBar';
import Home from './Pages/Home';
import Transactions from './Pages/Transactions';
import * as api from './services/api';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import TransactionDetails from './Pages/TransactionDetails';

function App() {
  const [transactions, setTransactions] = useState([]);
  const [selectedTransaction, setSelectedTransaction] = useState(null);

  useEffect(() => {
    const fetchTransactions = async () => {
      const data = await api.getTransactions();
      setTransactions(data);
    };

    fetchTransactions();
  }, []);

  const handleTransactionSelect = (transaction) => {
    setSelectedTransaction(transaction);
};


  return (
    <div>
      {/* <h1>Fraud Management Dashboard</h1> */}
      <div className="dashboard">
        <Router>
          <NavBar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/Transactions" element={<Transactions />}/>
            <Route path="/Transactions/Comments/:transactionId" element={<CommentSection />} />
            <Route path="/Transactions/TransactionDetails/:transactionId" element={<TransactionDetails />} />
          </Routes>
        </Router>
        {/* <CommentSection /> */}
        {/* <TransactionForm /> */}

      </div>
    </div>
  );
}

export default App;
