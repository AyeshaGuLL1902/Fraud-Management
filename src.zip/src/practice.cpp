#include <iostream>
using namespace std;
int main(){
    int arr[] = {1,3,2,4,2,6,3};
    int n = arr.length()/arr[0];
    for(int i=0; i<n; i++)
    {
        arr[arr[i]%n] = arr[arr[i]%n]+ n;
    }
    for(int i=0; i<n; i++)
    {
        if(arr[i]> n*2)
        cout<<i<<endl;
    }
    return 0;
}