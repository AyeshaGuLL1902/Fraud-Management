
// import React from 'react';
import TransactionList from "./TransactionList";
import './Transaction.css'


const Transactions = () => {

  return (
    <div className="bg-List" >
      <TransactionList />
    </div>
  );
};


export default Transactions;