import React, { useState } from 'react';
import * as api from '../services/api'; // Import API functions
import { Container,Button } from 'semantic-ui-react';
import { Input } from 'semantic-ui-react';
import { useParams } from 'react-router-dom';
import './Transaction.css'
import TransactionDetails from './TransactionDetails';


const CommentSection = () => {
  const { transactionId } = useParams(); // Use useParams directly inside the component

  const [comment, setComment] = useState('');

  const handleComment = async () => {
    if (comment.trim() !== '') {
      console.log(comment, transactionId);
      await api.commentTransaction(transactionId, comment);
      console.log(comment);
    }
  };

  return (

    <div className='CommentPlace'>
      <h3 className='Comment-heading'>Place Your Comments Here</h3>
      <Container>
        <div className="ui input">
          <input type="text"
            value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Comment" />
          </div><br></br>
        <Button className='btn-Comment' color='positive' onClick={() => handleComment(transactionId)}>Add Comment</Button>
      </Container>
    </div>

  );
};

export default CommentSection;
