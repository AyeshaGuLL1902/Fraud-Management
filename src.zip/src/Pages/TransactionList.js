import React, { useState, useEffect } from 'react';
import * as api from '../services/api'; // Import API functions
import { Container } from 'semantic-ui-react';
import { Table } from 'semantic-ui-react'
import { Button } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import './Transaction.css'
import CommentSection from './CommentSection';


const TransactionList = () => {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    const fetchTransactions = async () => {
      const data = await api.getTransactions(); // Fetch transactions from the backend
      setTransactions(data);
    };

    fetchTransactions();
  }, []);

  return (
    <div>
      <Container>
        <h2> Suspicious Transactions</h2>
        <div style={{ height: '500px', overflowY: 'auto' , overflowX: 'auto'}}>
          <Table celled>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell style={{ backgroundColor: '#dfc594' }}>TransactionID</Table.HeaderCell>
                <Table.HeaderCell style={{ backgroundColor: '#dfc594' }}>Amount</Table.HeaderCell>
                <Table.HeaderCell style={{ backgroundColor: '#dfc594' }}>Date</Table.HeaderCell>
                <Table.HeaderCell style={{ backgroundColor: '#dfc594' }}>Comment</Table.HeaderCell>
                <Table.HeaderCell style={{ backgroundColor: '#dfc594' }}>Actions</Table.HeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body style={{ backgroundColor: '#f3ebeb' }}>
              {transactions.map((transaction) => (
                <Table.Row key={transaction.id}>
                  <Table.Cell data-label="TransactionID">{transaction.id}</Table.Cell>
                  <Table.Cell data-label="Amount">{transaction.amount}</Table.Cell>
                  <Table.Cell data-label="Date">{transaction.date}</Table.Cell>
                  <Table.Cell data-label="Comment">
                    <ul>
                      {transaction.comments.map((comment, index) => (
                        <li key={index}>{comment}</li>
                      ))}
                    </ul>
                  </Table.Cell>
                  <Table.Cell data-label="Actions">
                    <Button color='red' onClick={() => api.flagTransaction(transaction.id)}>Flag</Button>
                    <Button color='positive' onClick={() => api.allowTransaction(transaction.id)}>Allow</Button>
                    <Button color='primary'
                      as={Link}
                      to={`/Transactions/Comments/${transaction.id}`}
                    >Comment</Button>
                    <Button color='secondary'
                      as={Link}
                      to={`/Transactions/TransactionDetails/${transaction.id}`}
                    >Details</Button>
                  </Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>
          </Table>
        </div>
      </Container>
      {/* <CommentSection/> */}
    </div>
  );
};

export default TransactionList;
