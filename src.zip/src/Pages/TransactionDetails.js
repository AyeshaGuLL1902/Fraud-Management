import React, { useState, useEffect } from 'react';
import * as api from '../services/api'; // Import API functions
import { useParams } from 'react-router-dom';
import { Container, Button } from 'semantic-ui-react';
import './Transaction.css'
import { Link } from 'react-router-dom';

const TransactionDetails = () => {
  const { transactionId } = useParams();
  const [transactionDetails, setTransactionDetails] = useState({});
  useEffect(() => {
    const fetchTransactionDetails = async () => {
      const data = await api.getTransactionDetails(transactionId);
      setTransactionDetails(data);
    };
    fetchTransactionDetails();
  }, [transactionId]);


  return (
    <div>
      {/* <div className='t-img'></div> */}
      <div className='t-details'>
        <Container>
          <h2>Transaction Details</h2>
          {transactionDetails && (
            <div>
              <p>Transaction ID: {transactionDetails.id}</p>
              <p>Amount: {transactionDetails.amount}</p>
              <p>Date: {transactionDetails.date}</p>
              {transactionDetails.comments && transactionDetails.comments.length > 0 ? (
                <div>
                  <p>Comments:</p>
                  <ul>
                    {transactionDetails.comments.map((comment, index) => (
                      <li key={index}>{comment}</li>
                    ))}
                  </ul>
                </div>
              ) : (
                <p>No comments available</p>
              )}
              {/* <p>Comments: {transactionDetails.comments.map((comment, index) => (<li key={index}>{comment}</li>))}</p> */}
              <p>Description: {transactionDetails.description}</p>
              <Button color='primary'
                as={Link}
                to={`/Transactions/Comments/${transactionDetails.id}`}
              >Add Comment</Button>
              <Button
                content="Back to Transactions"
                color='positive'
                as={Link}
                to="/Transactions"
              />

            </div>
          )}
        </Container>
      </div>
    </div>
  );
};

export default TransactionDetails;
