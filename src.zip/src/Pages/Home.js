// import React from 'react';
import {Button} from 'semantic-ui-react';
import Header from '../components/common/Header';
import { Link } from 'react-router-dom';

const Home = () => {

  return (
    <Header>
        
    <Button 
        content="View Transactions" 
        color='positive'
        as={Link}
        to="Transactions"
        size='big'
    />
    </Header>

  );
};

export default Home;
